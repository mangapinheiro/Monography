package br.ufla.dcc.pp;

public class Agent {

	public Agent(TargetRegion t) {
		target = t;
	}

	private TargetRegion target;

	public TargetRegion getTarget() {
		return target;
	}

}
