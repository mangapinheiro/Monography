package br.ufla.dcc.mac;

import br.ufla.dcc.grubix.simulator.LayerException;
import br.ufla.dcc.grubix.simulator.event.Packet;
import br.ufla.dcc.grubix.simulator.node.Layer;

public class BackBone_MAC
		extends Layer {

    @Override
    public void lowerSAP(Packet packet) throws LayerException {
	// TODO Auto-generated method stub

    }

    @Override
    public void upperSAP(Packet packet) throws LayerException {
	// TODO Auto-generated method stub

    }

}
