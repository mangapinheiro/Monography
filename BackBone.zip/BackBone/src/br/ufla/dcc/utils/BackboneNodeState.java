package br.ufla.dcc.utils;

public class BackboneNodeState {
    private BackboneNodeState(){}
    public static final String IS_BACKBONE = "3";
    public static final String IS_NOT_BACKBONE = "9";
    public static final String ERROR = "2";
}
