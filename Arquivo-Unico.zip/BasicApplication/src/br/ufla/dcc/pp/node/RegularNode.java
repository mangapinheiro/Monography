package br.ufla.dcc.pp.node;

import br.ufla.dcc.grubix.simulator.LayerException;
import br.ufla.dcc.grubix.simulator.NodeId;
import br.ufla.dcc.grubix.simulator.event.ApplicationPacket;
import br.ufla.dcc.grubix.simulator.event.Finalize;
import br.ufla.dcc.grubix.simulator.event.Packet;
import br.ufla.dcc.grubix.simulator.event.StartSimulation;
import br.ufla.dcc.grubix.simulator.event.TrafficGeneration;
import br.ufla.dcc.grubix.simulator.event.WakeUpCall;
import br.ufla.dcc.grubix.simulator.kernel.SimulationManager;
import br.ufla.dcc.grubix.simulator.node.ApplicationLayer;
import br.ufla.dcc.pp.Pacote;

//Classe que vai modelar o no' sensor
//Simula o comportamento do no' sensor
public class RegularNode extends ApplicationLayer {
//extends para a camada de aplicacao do no'
	
	@Override
	public int getPacketTypeCount() {
		return 1;
	}

	@Override
	public void processEvent(TrafficGeneration tg) {
	}

	// processa um pacote que vem de uma camada de baixo
	@Override
	public void lowerSAP(Packet packet){

		if (packet instanceof Pacote){		
		    System.out.println("PACOTE RECEBIDO!!!!!!!!!!!!!!!!");
		    
		    // pega o pacote que ele recebeu
		    Pacote pac = (Pacote)packet;
		    
		    // cria uma tag que chegou o pacote
		    SimulationManager.logNodeState(this.node.getId(), "Chegou pacote", "int", String.valueOf(pac.getCont()));
		    
		       // processa um evento daqui um tempo, cria um wakeup call para ser iniciado daqui um tempo de 1000
		       PingPongwuc wuc = new PingPongwuc(sender, 1000);
		    		       
		       // se o contador do pacote for menor que 30
		       if(pac.getCont() < 30){
		    	   
		    	   //seta o contador do wakeup call pro contador do pacote que ele recebeu
		    	   wuc.setCont(pac.getCont());
		    	   
		    	   //manda o evento para ele mesmo, para processar daqui um tempo de 1000
		       	   sendEventSelf(wuc);
		       }
		}
	}
	
// onde acontece o primeiro evento, evento inicial
	protected void processEvent(StartSimulation start) {
		
		if (this.node.getId().asInt() == 1)
		{
		   // cria o pacote com o destino em que vai enviar, e o endereço dele, e vai enviar para o no' 2
		   Pacote pk2 = new Pacote(sender,NodeId.get(2));
		   
		   // seta o valor do contador para 2
		   pk2.setCont(2);
		   
		   // envia o pacote da camada de aplicacao
		   sendPacket(pk2);
		   
		   System.out.println(pk2.getCont());
		   
		   // cria uma tag desse evento
		   SimulationManager.logNodeState(this.node.getId(), "Primeiro-envio", "int", String.valueOf(15));
		}
	}
	   
	protected void processEvent(Finalize finalize) {
	}
	//processa o Wakeup call desse no'
	public void processWakeUpCall(WakeUpCall wuc)
	{
		// se o wakeup call recebido for do tipo pingpongwuc ele irá processar 		
		if (wuc instanceof PingPongwuc)
		{
			   // ele pega o contador o wakeup call e incrementa 1	
			   int teste = ((PingPongwuc) wuc).getCont()+1;
			   
			   // cria um novo pacote e manda para o proximo
			   Pacote pk = new Pacote(sender,NodeId.get(teste));
			   
			   // seta o contador do pacote como teste
			   pk.setCont(teste);
			   
			   System.out.println(pk.getCont());
			   
			   //envia o pacote para o proximo
			   sendPacket(pk);
		}
	}
}
