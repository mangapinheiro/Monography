package br.ufla.dcc.pp.node;

import br.ufla.dcc.grubix.simulator.Address;
import br.ufla.dcc.grubix.simulator.event.WakeUpCall;

public class PingPongwuc extends WakeUpCall {

	private int cont;	
	
	
	public int getCont() {
		return cont;
	}

	public void setCont(int cont) {
		this.cont = cont;
	}
	// vai ter quem manda o evento de acordar para processar um evento, e tem um tempo gasto para iniciar esse evento
	public PingPongwuc(Address sender, double delay) {
		super(sender, delay);
	}

	public PingPongwuc(Address sender) {
		super(sender);
	}

}
