package br.ufla.dcc.pp;

import br.ufla.dcc.grubix.simulator.Address;
import br.ufla.dcc.grubix.simulator.NodeId;
import br.ufla.dcc.grubix.simulator.event.ApplicationPacket;

public class Pacote extends ApplicationPacket{
	
	private int cont;
	
	

	public int getCont() {
		return cont;
	}



	public void setCont(int cont) {
		this.cont = cont;
	}



	public Pacote(Address sender, NodeId receiver) {
		super(sender, receiver);
		// TODO Auto-generated constructor stub
	}
	
	

}
