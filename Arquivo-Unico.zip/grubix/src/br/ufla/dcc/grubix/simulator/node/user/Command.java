package br.ufla.dcc.grubix.simulator.node.user;

public class Command {

}
